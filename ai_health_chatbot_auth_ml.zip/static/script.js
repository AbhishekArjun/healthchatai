document.addEventListener("DOMContentLoaded", function(){
  const sendBtn = document.getElementById("send");
  const input = document.getElementById("user-input");
  const chatLog = document.getElementById("chat-log");
  sendBtn.addEventListener("click", async ()=>{
    const text = input.value.trim();
    if(!text) return;
    const p = document.createElement("p"); p.innerHTML = "<b>You:</b> "+text; chatLog.appendChild(p);
    input.value = "";
    chatLog.scrollTop = chatLog.scrollHeight;
    const res = await fetch("/chat", {
      method:"POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message: text})
    });
    const data = await res.json();
    const r = document.createElement("p"); r.innerHTML = "<b>AI:</b> "+data.reply.replace(/\n/g,"<br>"); chatLog.appendChild(r);
    chatLog.scrollTop = chatLog.scrollHeight;
  });

  // Find doctors
  document.getElementById("search-doctor").addEventListener("click", async ()=>{
    const q = document.getElementById("doctor-query").value;
    const res = await fetch("/find_doctor?specialty="+encodeURIComponent(q));
    const data = await res.json();
    const ul = document.getElementById("doctor-results"); ul.innerHTML = "";
    data.doctors.forEach(d=>{
      const li = document.createElement("li"); li.className="list-group-item"; li.innerText = d.name+" — "+d.specialty+" ("+d.location+")";
      ul.appendChild(li);
    });
  });

  // Booking
  document.getElementById("book").addEventListener("click", async ()=>{
    const name = document.getElementById("pname").value;
    const doctor = document.getElementById("pdoctor").value;
    const date = document.getElementById("pdate").value;
    const time = document.getElementById("ptime").value;
    const res = await fetch("/book", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({name, doctor, date, time})
    });
    const data = await res.json();
    document.getElementById("book-result").innerText = data.message || data.error || JSON.stringify(data);
  });
});
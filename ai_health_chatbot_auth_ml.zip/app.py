from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, UserMixin, current_user
import os, pickle
from pathlib import Path

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database setup
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

# Login Manager setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# User model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Load or train model
BASE = Path(__file__).parent
MODEL_PATH = BASE / "model" / "model.pkl"
VECT_PATH = BASE / "model" / "vect.pkl"

if not MODEL_PATH.exists() or not VECT_PATH.exists():
    # train using included script
    try:
        from train_model import train_and_save
        train_and_save(MODEL_PATH, VECT_PATH, None)
    except Exception as e:
        print("Unable to auto-train model:", e)

if MODEL_PATH.exists() and VECT_PATH.exists():
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    with open(VECT_PATH, "rb") as f:
        vect = pickle.load(f)
else:
    model = None
    vect = None

health_tips = [
    "Remember to drink at least 8 glasses of water daily.",
    "Take a 10-minute walk after meals to aid digestion.",
    "Maintain a balanced diet with fruits and vegetables.",
    "Get 7-8 hours of sleep every night.",
]

doctors = [
    {"name": "Dr. A. Singh", "specialty": "General Physician", "location": "Raxaul"},
    {"name": "Dr. N. Kumar", "specialty": "Cardiologist", "location": "Patna"},
    {"name": "Dr. P. Sharma", "specialty": "Dermatologist", "location": "Gorakhpur"},
]

@app.route('/')
@login_required
def home():
    return render_template("index.html", tips=health_tips, doctors=doctors, user=current_user.username)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash("Username already exists!", "danger")
            return redirect(url_for('signup'))
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash("Signup successful! Please login.", "success")
        return redirect(url_for('login'))
    return render_template("signup.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            login_user(user)
            flash("Login successful!", "success")
            return redirect(url_for('home'))
        flash("Invalid username or password", "danger")
    return render_template("login.html")

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logged out successfully!", "info")
    return redirect(url_for('login'))

# Chat endpoint - uses model if available, else fallback rule-based replies
@app.route('/chat', methods=['POST'])
@login_required
def chat():
    data = request.get_json() or request.form or {}
    message = data.get("message", "")
    if not message.strip():
        return jsonify({"reply":"Please describe your symptoms or say hello."})
    if model is not None and vect is not None:
        X = vect.transform([message])
        pred = model.predict(X)[0]
        proba = float(model.predict_proba(X).max())
        reply = f"I think your symptoms match something like *{pred}* (confidence: {proba:.2f}).\\nThis is not a medical diagnosis."
    else:
        # simple rule-based
        m = message.lower()
        if "fever" in m:
            reply = "It seems you may have fever. Rest and hydrate. If it persists, consult a doctor."
            pred = "Fever"
            proba = 0.6
        elif "headache" in m:
            reply = "Try resting in a quiet, dark room and stay hydrated. Consult if severe."
            pred = "Headache"
            proba = 0.6
        else:
            reply = "I'm not sure — please provide more symptoms."
            pred = "Unknown"
            proba = 0.0
    return jsonify({"reply": reply, "prediction": pred, "confidence": proba})

@app.route('/find_doctor', methods=['GET'])
@login_required
def find_doctor():
    specialty = request.args.get("specialty", "").lower()
    results = [d for d in doctors if specialty in d["specialty"].lower() or not specialty]
    return jsonify({"doctors": results})

@app.route('/book', methods=['POST'])
@login_required
def book():
    data = request.get_json() or request.form or {}
    name = data.get("name")
    doctor = data.get("doctor")
    date = data.get("date")
    time = data.get("time")
    if not (name and doctor and date):
        return jsonify({"status":"error", "message":"name, doctor and date required"}), 400
    # In a real app you'd save to DB. Here we return success.
    return jsonify({"status":"ok", "message":f"Appointment booked with {doctor} on {date} {('at '+time) if time else ''} for {name}."})

if __name__ == "__main__":
    if not os.path.exists("users.db"):
        db.create_all()
    app.run(debug=True)
